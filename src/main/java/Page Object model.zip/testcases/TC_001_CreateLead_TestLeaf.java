package testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pages.MyHomePage;

public class TC_001_CreateLead_TestLeaf extends Annotations1{
	
	public String testCase, testDesc, iteration, author, category, fileName;
	
	@BeforeTest
	public void setValues()
	{
		testCase ="TC001_Create Lead";
		testDesc="Create a lead in Test Leaf";
		iteration="Leads";
		author="Vishveshwar";
		category="Smoke";
	    fileName="TC_001_CreateLead_TestCase";
	}
	
	
	
	@Test(dataProvider="fetchData")
	public void createLeadTestCase(String cName,String fName,String lName)
	{
		new MyHomePage()
		.clickLeads()
		.clickCreateLead()
		.typeCompanyName(cName)
		.typeFirstName(fName)
		.typeLastName(lName)
		.clickSubmit()
		.verifyFirstName(fName);
	}

}
